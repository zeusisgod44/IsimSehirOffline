# APK oluşturma (Türkçe)

Bu zip **kaynak kod projesidir; derlenmiş APK değildir**.

## Bilgisayarda (Android Studio ile)

1. [Android Studio](https://developer.android.com/studio) kurulu olmalı.
2. ZIP dosyasını çıkar, Android Studio > **Open** > `IsimSehirOffline` klasörünü aç.
3. İlk açılışta Gradle / SDK bağımlılıklarının indirilmesine izin ver. Proje Java 17, Gradle 8.9 ve Android SDK 35 hedefler.
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)** seç.
5. Oluşan dosya: `app/build/outputs/apk/debug/app-debug.apk`.
6. Bu APK'yı Android telefonlara göndererek yükleyebilirsin.

## Bilgisayar yoksa (GitHub Actions)

Kodları bir GitHub deposuna aktarırsan `.github/workflows/build-apk.yml` otomatik APK oluşturacak.
- GitHub deposu > **Actions** > **Android APK** > **Run workflow**.
- İşlem tamamlanınca çalıştırma sayfasının **Artifacts** bölümünden **IsimSehirOffline-debug-apk** dosyasını indir.

Not: GitHub Actions'ın çalışması için projenin dosyaları GitHub deposuna **zipin içeriği olarak** yüklenmelidir. ZIP dosyasını yalnızca depoya koymak yeterli değildir. Telefonda GitHub Codespaces üzerinden zipi açıp depoya commit etmek bir yoldur; GitHub arayüzleri sürüme göre değişebilir.

### Oyuncuların bağlantısı

**Bluetooth bu sürümde yok.** Tüm oyuncular aynı Wi‑Fi veya hotspot ağına bağlanır. Ana oyuncu oda IP adresini ekrandan kopyalar. Diğerleri bu IP ile katılır. Oyun internet bağlantısına ihtiyaç duymaz.

APK yalnızca **Android** içindir; **iPhone'a kurulmaz**. iOS için ayrıca iOS uygulaması gerekir.

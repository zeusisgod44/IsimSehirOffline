# İsim Şehir Offline — Android (Java)

**Yerel ağ üzerinden internetsiz, 2–8 kişilik kooperatif/rekabetçi İsim Şehir oyunu.**

## Nasıl oynanır?

1. Android telefonlarda aynı Wi-Fi ağına bağlanın. Modemin internet bağlantısının olması şart değildir. Alternatif olarak bir telefondan **hotspot** açıp diğerlerini ona bağlayın. Bazı telefonlarda hotspot istemci izolasyonu bağlantıyı engelleyebilir; bu durumda ortak Wi-Fi kullanın.
2. Bir kişi uygulamada **Oda Kur**'a basar. Odanın gösterdiği yerel IPv4 adresini paylaşır (`192.168.x.x` veya `10.x.x.x`).
3. Diğer Android cihazlar **Odaya Katıl** kısmına IP'yi yazar. Herkes aynı uygulamayı kurmuş olmalı.
4. Oda sahibi 60 / 90 / 120 saniyelik tur süresi ile 3 / 5 / 10 tur sayısı seçer.
5. Rastgele ortak harf gelir. İsim, Şehir, Hayvan, Bitki, Eşya, Ülke alanlarını doldurup **Cevapları Gönder**'e basın. Herkes gönderdiğinde veya süre bitince oylama başlar.
6. Başkalarının her cevabını **✓ Kabul / ✕ Ret** ile oylayın. Kendi cevabınıza oy veremezsiniz. Bir cevaba oy birliğiyle **diğer tüm oyuncular** evet derse ve cevap verilen harfle başlıyorsa geçerli sayılır.
7. Oylama için 150 saniye vardır. Oy kullanılmamış cevaplar oy birliği sağlayamadığından reddedilir. Herkes tüm oylamalarını yaparsa otomatik bitirilir.
8. Aynı kategoride kabul edilen **benzersiz** cevap 10 puan; aynı cevabı veren birden çok oyuncu varsa **her biri 5** puan; reddedilen/harf uyuşmayan 0 puan. Son tur sonunda yüksek puan kazanır; eşitlikte birden fazla kazanan gösterilir.

> Örnek: Harf **A**, kategori **İsim**, cevap **Armut**. Oyuncular oybirliğiyle reddederse 0 puan.

## Telefondan APK alma (GitHub Actions)

Proje zip dosyasının **içinde APK yoktur**; otomatik derleme dosyası `.github/workflows/build-apk.yml` vardır.

Bilgisayar kullanmadan Android APK elde etmek için:

1. GitHub hesabında **boş bir depo** oluşturun (ör. `isim-sehir-offline`).
2. Bu projenin **içindeki dosya ve klasörleri** depo köküne, dizinleri koruyarak yükleyin. ZIP dosyasını tek bir dosya olarak yüklemek yeterli değildir.
3. GitHub'da **Actions > APK Olustur** akışının yeşil tikle bitmesini bekleyin. Gerekirse `Run workflow` ile başlatın.
4. Actions çalışmasının en altındaki **Artifacts > IsimSehirOffline-APK** bağlantısına basın. İnen ZIP'in içinden `app-debug.apk` dosyasını çıkarın. Android telefonda kurun.

GitHub Actions için GitHub hesabı ve **derleme sırasında internet** gerekir; oyunun kendisi internet kullanmadan yerel ağda çalışır.

**APK burada üretilmiş veya Android cihazda test edilmiş değildir.** GitHub derleme günlüklerine göre ek düzeltme gerekebilir.

## APK'yı oluşturma

Bu klasör bir **Android Studio / Gradle projesidir**; Android Studio'da `File > Open` ile bu klasörü seçin. Gradle ve Android SDK 35 gereklidir. `Build > Build Bundle(s) / APK(s) > Build APK(s)` seçin. Bilgisayarsız GitHub Actions seçeneği için `APK-OLUSTURMA.md` dosyasına bakın. APK varsayılan olarak `app/build/outputs/apk/debug/app-debug.apk` altında oluşur. Android Studio derleme için interneti **ilk kez geliştirme ortamı bağımlılıklarını indirirken** kullanabilir; **oyun oynamak için internet bağlantısı gerekmez.**

Android Studio sürümünüz proje Gradle sürümü ile uyumlu olmalıdır (AGP 8.7.3 / Gradle 8.9 / JDK 17). Gradle yüklü ortamda `gradle assembleDebug` komutu da kullanılabilir. Projede üçüncü parti uygulama kütüphanesi yoktur.

**Önemli:** Bu çalışma ortamında Android SDK ve Gradle kurulumu olmadığı için burada APK derlemesi / cihaz testi yapılamadı. Kaynak kodu ve bağımsız oyun mantığı testleri hazırlanmıştır. Bu proje Android içindir; iOS/iPhone'a `.apk` kurulamaz.

## İletişim ve gizlilik

- TCP/IP (port `39477`), yalnızca yerel ağ. Merkezi sunucu, hesap, reklam veya Firebase yok.
- `INTERNET` Android izni, yerel TCP soketleri için gereklidir; **mobil internet tüketimi** anlamına gelmez.
- Oyuncu cevapları oylama başlayana kadar diğer oyunculara iletilmez. Sunucu/oda sahibi tur ve skor kararlarında otoritedir.
- Oda sahibi uygulamadan çıkarsa herkesin bağlantısı kesilir. Cihazın ekranını açık tutun; bu ilk sürümde arka plan servisi kullanılmıyor.
- İlk sürümde otomatik oda keşfi veya Bluetooth eşleşmesi yok; **aynı yerel ağ/hotspot üzerinden IP ile katılma** uygulanmıştır.
- Oyuncular arası bağlantılar yerel ağda şifrelenmemiş TCP kullanır. Tanımadığınız/güvenmediğiniz ağlarda kullanmayın.

## Dizinler

- `app/src/main/java/com/offlineisimsehir/game/GameEngine.java` — tur, harf, puan, oylama ve durum makinesi.
- `LanHost.java` — oda sunucusu, eşleştirme, mesaj doğrulama, kişiye özel durum iletimi.
- `LanClient.java` — yerel ağ istemcisi.
- `MainActivity.java` — bütün ekranlar ve native Android arayüzü.
- `NetworkUtils.java` — yerel IPv4 adreslerini bulma.
- `tests/GameEngineTest.java` — JDK ile çalıştırılabilir puanlama ve akış testleri.

## Bağımsız mantık testini çalıştırma

`javac -encoding UTF-8 -d tests/out app/src/main/java/com/offlineisimsehir/game/GameEngine.java tests/GameEngineTest.java && java -cp tests/out GameEngineTest`

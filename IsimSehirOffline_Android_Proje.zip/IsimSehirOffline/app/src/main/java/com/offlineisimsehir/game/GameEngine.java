package com.offlineisimsehir.game;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Authoritative state machine. No Android dependencies: can be tested with ordinary Java. */
public final class GameEngine {
    public enum Phase { LOBBY, WRITING, VOTING, RESULTS }
    public static final String[] CATEGORIES = {"İsim", "Şehir", "Hayvan", "Bitki", "Eşya", "Ülke"};
    public static final int MAX_PLAYERS = 8;
    public static final int VOTING_SECONDS = 150;
    private static final Locale TURKISH = Locale.forLanguageTag("tr-TR");
    private static final String[] LETTERS = {"A", "B", "C", "Ç", "D", "E", "F", "G", "H", "İ", "K", "L", "M", "N", "O", "P", "R", "S", "Ş", "T", "U", "Y", "Z"};

    public static final class Player {
        public final String id;
        public final String name;
        public final boolean host;
        public int score;
        public boolean submitted;
        public final Map<String, String> answers = new LinkedHashMap<>();
        Player(String id, String name, boolean host) {
            this.id = id;
            this.name = name;
            this.host = host;
        }
    }
    public static final class Entry {
        public final String id;
        public final String ownerId;
        public final String category;
        public final String answer;
        public final Map<String, Boolean> votes = new LinkedHashMap<>();
        public boolean accepted;
        public int points;
        public String reason = "";
        Entry(String id, String ownerId, String category, String answer) {
            this.id = id;
            this.ownerId = ownerId;
            this.category = category;
            this.answer = answer;
        }
    }

    private final LinkedHashMap<String, Player> players = new LinkedHashMap<>();
    private final List<Entry> entries = new ArrayList<>();
    private final List<String> shuffledLetters = new ArrayList<>();
    private final Random random = new Random();
    private Phase phase = Phase.LOBBY;
    private String letter = "";
    private int round = 0;
    private int rounds = 5;
    private int answerSeconds = 90;
    private long deadlineMs;

    public synchronized Player addPlayer(String requestedName, boolean isHost) {
        if (phase != Phase.LOBBY) throw new IllegalStateException("Oyun başladı; yeni oyuncu şu anda katılamaz.");
        if (players.size() >= MAX_PLAYERS) throw new IllegalStateException("Oda dolu (en fazla 8 oyuncu).");
        for (Player p : players.values()) {
            if (isHost && p.host) throw new IllegalStateException("Odanın zaten bir yöneticisi var.");
        }
        String name = requestedName == null ? "" : requestedName.trim();
        name = name.replace('\n', ' ').replace('\r', ' ');
        if (name.length() > 18) name = name.substring(0, 18);
        if (name.isEmpty()) name = "Oyuncu";
        String base = name;
        int suffix = 2;
        boolean duplicate;
        do {
            duplicate = false;
            for (Player p : players.values()) {
                if (p.name.equalsIgnoreCase(name)) { duplicate = true; break; }
            }
            if (duplicate) name = base + " " + suffix++;
        } while (duplicate);
        Player player = new Player(UUID.randomUUID().toString(), name, isHost);
        players.put(player.id, player);
        return player;
    }

    public synchronized void removePlayer(String playerId) {
        if (!players.containsKey(playerId)) return;
        players.remove(playerId);
        entries.removeIf(e -> e.ownerId.equals(playerId));
        for (Entry e : entries) e.votes.remove(playerId);
        if (phase == Phase.WRITING && everyoneSubmitted()) beginVoting();
        if (phase == Phase.VOTING && allVoted()) finishVoting();
    }

    public synchronized List<Player> getPlayers() { return new ArrayList<>(players.values()); }
    public synchronized List<Entry> getEntries() { return new ArrayList<>(entries); }
    public synchronized Player findPlayer(String id) { return players.get(id); }
    public synchronized Phase getPhase() { return phase; }
    public synchronized String getLetter() { return letter; }
    public synchronized int getRound() { return round; }
    public synchronized int getRounds() { return rounds; }
    public synchronized int getAnswerSeconds() { return answerSeconds; }
    public synchronized long getRemainingMs() {
        if (phase != Phase.WRITING && phase != Phase.VOTING) return 0;
        return Math.max(0, deadlineMs - System.currentTimeMillis());
    }
    public synchronized boolean isFinalResults() { return phase == Phase.RESULTS && round >= rounds; }

    public synchronized void settings(String playerId, int seconds, int totalRounds) {
        checkHost(playerId);
        if (phase != Phase.LOBBY) throw new IllegalStateException("Ayarlar yalnızca lobide değiştirilebilir.");
        if (seconds != 60 && seconds != 90 && seconds != 120) throw new IllegalArgumentException("Geçersiz tur süresi.");
        if (totalRounds != 3 && totalRounds != 5 && totalRounds != 10) throw new IllegalArgumentException("Geçersiz tur sayısı.");
        answerSeconds = seconds;
        rounds = totalRounds;
    }

    public synchronized void start(String playerId) {
        checkHost(playerId);
        if (phase != Phase.LOBBY) throw new IllegalStateException("Oyun zaten başladı.");
        if (players.size() < 2) throw new IllegalStateException("Oynamak için en az 2 kişi gerekli.");
        round = 0;
        for (Player p : players.values()) p.score = 0;
        shuffledLetters.clear();
        Collections.addAll(shuffledLetters, LETTERS);
        Collections.shuffle(shuffledLetters, random);
        nextRoundInternal();
    }

    public synchronized void nextRound(String playerId) {
        checkHost(playerId);
        if (phase != Phase.RESULTS || round >= rounds) throw new IllegalStateException("Yeni tura geçilemiyor.");
        nextRoundInternal();
    }

    public synchronized void restart(String playerId) {
        checkHost(playerId);
        if (phase != Phase.RESULTS || round < rounds) throw new IllegalStateException("Oyun henüz bitmedi.");
        phase = Phase.LOBBY;
        round = 0;
        letter = "";
        entries.clear();
        for (Player p : players.values()) {
            p.score = 0;
            p.submitted = false;
            p.answers.clear();
        }
    }

    private void nextRoundInternal() {
        if (round >= rounds) return;
        round++;
        phase = Phase.WRITING;
        if (shuffledLetters.isEmpty()) {
            Collections.addAll(shuffledLetters, LETTERS);
            Collections.shuffle(shuffledLetters, random);
        }
        letter = shuffledLetters.remove(0);
        entries.clear();
        for (Player p : players.values()) {
            p.submitted = false;
            p.answers.clear();
        }
        deadlineMs = System.currentTimeMillis() + answerSeconds * 1000L;
    }

    public synchronized void submit(String playerId, Map<String, String> answers) {
        Player p = requirePlayer(playerId);
        if (phase == Phase.WRITING && System.currentTimeMillis() >= deadlineMs) beginVoting();
        if (phase != Phase.WRITING || p.submitted) throw new IllegalStateException("Cevap gönderme süresi sona erdi.");
        p.answers.clear();
        for (String category : CATEGORIES) {
            String answer = answers.get(category);
            if (answer == null) answer = "";
            answer = answer.replace('\n', ' ').replace('\r', ' ').trim();
            if (answer.length() > 40) answer = answer.substring(0, 40);
            p.answers.put(category, answer);
        }
        p.submitted = true;
        if (everyoneSubmitted()) beginVoting();
    }

    private boolean everyoneSubmitted() {
        if (players.isEmpty()) return false;
        for (Player p : players.values()) if (!p.submitted) return false;
        return true;
    }

    private void beginVoting() {
        if (phase != Phase.WRITING) return;
        entries.clear();
        for (Player p : players.values()) {
            for (int i = 0; i < CATEGORIES.length; i++) {
                String category = CATEGORIES[i];
                String word = p.answers.get(category);
                if (word != null && !word.trim().isEmpty()) {
                    entries.add(new Entry(round + ":" + p.id + ":" + i, p.id, category, word));
                }
            }
        }
        phase = Phase.VOTING;
        deadlineMs = System.currentTimeMillis() + VOTING_SECONDS * 1000L;
        if (entries.isEmpty() || players.size() < 2) finishVoting();
    }

    public synchronized void vote(String voterId, String entryId, boolean yes) {
        requirePlayer(voterId);
        if (phase == Phase.VOTING && System.currentTimeMillis() >= deadlineMs) finishVoting();
        if (phase != Phase.VOTING) throw new IllegalStateException("Oylama şu an açık değil.");
        Entry found = null;
        for (Entry e : entries) if (e.id.equals(entryId)) { found = e; break; }
        if (found == null) throw new IllegalArgumentException("Cevap bulunamadı.");
        if (found.ownerId.equals(voterId)) throw new IllegalArgumentException("Kendi cevabına oy veremezsin.");
        found.votes.put(voterId, yes); // Oy süresi bitmeden değiştirilebilir.
        if (allVoted()) finishVoting();
    }

    private boolean allVoted() {
        if (phase != Phase.VOTING) return false;
        for (Entry e : entries) {
            for (Player p : players.values()) {
                if (!p.id.equals(e.ownerId) && !e.votes.containsKey(p.id)) return false;
            }
        }
        return true;
    }

    public synchronized boolean tick() {
        if ((phase == Phase.WRITING || phase == Phase.VOTING) && System.currentTimeMillis() >= deadlineMs) {
            if (phase == Phase.WRITING) beginVoting();
            else finishVoting();
            return true;
        }
        return false;
    }

    private void finishVoting() {
        if (phase != Phase.VOTING) return;
        for (Entry e : entries) {
            int expected = 0;
            boolean unanimous = true;
            for (Player p : players.values()) {
                if (!p.id.equals(e.ownerId)) {
                    expected++;
                    if (!Boolean.TRUE.equals(e.votes.get(p.id))) unanimous = false;
                }
            }
            boolean startsWithLetter = normalized(e.answer).startsWith(letter);
            e.accepted = expected >= 1 && unanimous && startsWithLetter;
            if (!startsWithLetter) e.reason = "Harf uyuşmuyor";
            else if (!unanimous) e.reason = "Oy birliği yok";
            else if (expected == 0) e.reason = "Onaylayan oyuncu yok";
            else e.reason = "Oy birliğiyle kabul";
        }
        for (Entry e : entries) {
            if (!e.accepted) continue;
            int matching = 0;
            for (Entry other : entries) {
                if (other.accepted && other.category.equals(e.category) && normalized(other.answer).equals(normalized(e.answer))) matching++;
            }
            e.points = matching > 1 ? 5 : 10;
            Player owner = players.get(e.ownerId);
            if (owner != null) owner.score += e.points;
            if (matching > 1) e.reason = "Aynı cevabı başkası da yazmış";
        }
        phase = Phase.RESULTS;
        deadlineMs = 0;
    }

    public static String normalized(String word) {
        if (word == null) return "";
        return Normalizer.normalize(word.trim().replaceAll("\\s+", " "), Normalizer.Form.NFC).toUpperCase(TURKISH);
    }

    private void checkHost(String playerId) {
        Player p = requirePlayer(playerId);
        if (!p.host) throw new SecurityException("Bu işlemi yalnızca oda sahibi yapabilir.");
    }
    private Player requirePlayer(String id) {
        Player p = players.get(id);
        if (p == null) throw new SecurityException("Oyuncu bulunamadı.");
        return p;
    }
}

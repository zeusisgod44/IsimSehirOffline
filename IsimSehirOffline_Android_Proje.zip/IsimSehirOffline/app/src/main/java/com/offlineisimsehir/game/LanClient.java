package com.offlineisimsehir.game;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/** Lightweight LAN TCP client; all reads happen off the UI thread. */
public final class LanClient {
    public interface Listener {
        void onWelcome(String id);
        void onState(JSONObject state);
        void onError(String message);
        void onDisconnected();
    }
    private final String ip;
    private final String name;
    private final String hostToken;
    private final Listener listener;
    private volatile boolean closed;
    private Socket socket;
    private BufferedWriter writer;

    public LanClient(String ip, String name, String hostToken, Listener listener) {
        this.ip = ip;
        this.name = name;
        this.hostToken = hostToken;
        this.listener = listener;
    }
    public void connect() {
        Thread t = new Thread(() -> {
            try {
                Socket connection = new Socket();
                socket = connection;
                connection.connect(new InetSocketAddress(ip, LanHost.PORT), 6000);
                connection.setTcpNoDelay(true);
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
                writer = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream(), StandardCharsets.UTF_8));
                JSONObject hello = new JSONObject().put("type", "hello").put("name", name);
                if (hostToken != null) hello.put("hostToken", hostToken);
                send(hello);
                String line;
                while (!closed && (line = reader.readLine()) != null) {
                    JSONObject json = new JSONObject(line);
                    switch (json.optString("type")) {
                        case "welcome": listener.onWelcome(json.optString("id")); break;
                        case "state": listener.onState(json); break;
                        case "error": listener.onError(json.optString("message", "Bir hata oluştu.")); break;
                    }
                }
            } catch (Exception e) {
                if (!closed) listener.onError("Bağlantı kurulamadı: " + (e.getMessage() == null ? "ağ hatası" : e.getMessage()));
            } finally {
                boolean wasClosed = closed;
                close();
                if (!wasClosed) listener.onDisconnected();
            }
        }, "room-client");
        t.setDaemon(true);
        t.start();
    }
    public synchronized void send(JSONObject json) {
        if (closed || writer == null) return;
        try { writer.write(json.toString()); writer.write('\n'); writer.flush(); }
        catch (Exception e) {
            if (!closed) listener.onError("Mesaj gönderilemedi: " + e.getMessage());
            close();
        }
    }
    public synchronized void close() {
        closed = true;
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
    }
}

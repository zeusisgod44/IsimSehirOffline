package com.offlineisimsehir.game;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Local-only TCP room server; all commands are checked against authoritative GameEngine. */
public final class LanHost {
    public static final int PORT = 39477;
    private final GameEngine game = new GameEngine();
    private final Map<String, Session> sessions = new LinkedHashMap<>();
    private final ScheduledExecutorService pool = Executors.newScheduledThreadPool(2);
    private final String secret = UUID.randomUUID().toString();
    private ServerSocket server;
    private volatile boolean running;

    private static final class Session {
        final Socket socket;
        final BufferedReader reader;
        final BufferedWriter writer;
        String playerId;
        Session(Socket socket) throws Exception {
            this.socket = socket;
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8));
        }
        synchronized void send(JSONObject json) throws Exception {
            writer.write(json.toString());
            writer.write('\n');
            writer.flush();
        }
        void close() { try { socket.close(); } catch (Exception ignored) {} }
    }

    public synchronized void start() throws Exception {
        server = new ServerSocket(PORT);
        running = true;
        pool.execute(() -> {
            while (running) {
                try {
                    Socket socket = server.accept();
                    socket.setTcpNoDelay(true);
                    socket.setSoTimeout(25000);
                    Thread thread = new Thread(() -> serve(socket), "room-peer");
                    thread.setDaemon(true);
                    thread.start();
                } catch (Exception ignored) { if (!running) return; }
            }
        });
        pool.scheduleAtFixedRate(() -> {
            synchronized (LanHost.this) {
                if (!running) return;
                game.tick();
                broadcast();
            }
        }, 0, 1, TimeUnit.SECONDS);
    }

    public String hostSecret() { return secret; }

    private void serve(Socket socket) {
        Session session = null;
        try {
            session = new Session(socket);
            String greeting = session.reader.readLine();
            if (greeting == null || greeting.length() > 4096) return;
            JSONObject hello = new JSONObject(greeting);
            if (!"hello".equals(hello.optString("type"))) return;
            synchronized (this) {
                if (!running) return;
                boolean host = secret.equals(hello.optString("hostToken")) && !secret.isEmpty();
                GameEngine.Player p = game.addPlayer(hello.optString("name"), host);
                session.playerId = p.id;
                sessions.put(p.id, session);
                session.send(new JSONObject().put("type", "welcome").put("id", p.id));
                broadcast();
            }
            socket.setSoTimeout(0);
            String line;
            while (running && (line = session.reader.readLine()) != null) {
                if (line.length() > 16000) throw new IllegalArgumentException("Mesaj sınırı aşıldı.");
                try {
                    JSONObject message = new JSONObject(line);
                    synchronized (this) {
                        if (running && session.playerId != null) {
                            dispatch(session.playerId, message);
                            broadcast();
                        }
                    }
                } catch (Exception e) {
                    try { session.send(new JSONObject().put("type", "error").put("message", e.getMessage() == null ? "İşlem başarısız." : e.getMessage())); }
                    catch (Exception ignored) {}
                }
            }
        } catch (Exception e) {
            if (session != null) {
                try { session.send(new JSONObject().put("type", "error").put("message", e.getMessage() == null ? "Bağlantı kurulamadı." : e.getMessage())); }
                catch (Exception ignored) {}
            }
        } finally {
            if (session != null) {
                synchronized (this) {
                    if (session.playerId != null) {
                        sessions.remove(session.playerId);
                        game.removePlayer(session.playerId);
                        broadcast();
                    }
                }
                session.close();
            } else { try { socket.close(); } catch (Exception ignored) {} }
        }
    }

    private void dispatch(String playerId, JSONObject message) {
        String type = message.optString("type", "");
        switch (type) {
            case "settings":
                game.settings(playerId, message.optInt("seconds"), message.optInt("rounds"));
                break;
            case "start":
                game.start(playerId);
                break;
            case "submit": {
                JSONObject a = message.optJSONObject("answers");
                Map<String, String> map = new HashMap<>();
                for (String cat : GameEngine.CATEGORIES) map.put(cat, a == null ? "" : a.optString(cat, ""));
                game.submit(playerId, map);
                break;
            }
            case "vote":
                game.vote(playerId, message.optString("entryId"), message.optBoolean("yes"));
                break;
            case "next":
                game.nextRound(playerId);
                break;
            case "restart":
                game.restart(playerId);
                break;
            default:
                throw new IllegalArgumentException("Bilinmeyen işlem.");
        }
    }

    private void broadcast() {
        List<Session> dead = new ArrayList<>();
        for (Session session : new ArrayList<>(sessions.values())) {
            try { session.send(stateFor(session.playerId)); }
            catch (Exception e) { dead.add(session); }
        }
        for (Session s : dead) s.close();
    }

    private JSONObject stateFor(String viewer) throws Exception {
        JSONObject json = new JSONObject();
        json.put("type", "state");
        json.put("phase", game.getPhase().name());
        json.put("round", game.getRound());
        json.put("rounds", game.getRounds());
        json.put("letter", game.getLetter());
        json.put("seconds", game.getAnswerSeconds());
        json.put("remainingMs", game.getRemainingMs());
        json.put("final", game.isFinalResults());
        JSONArray participants = new JSONArray();
        List<GameEngine.Player> players = game.getPlayers();
        for (GameEngine.Player p : players) {
            JSONObject po = new JSONObject();
            po.put("id", p.id);
            po.put("name", p.name);
            po.put("score", p.score);
            po.put("submitted", p.submitted);
            po.put("host", p.host);
            participants.put(po);
        }
        json.put("players", participants);
        if (game.getPhase() == GameEngine.Phase.WRITING) {
            GameEngine.Player p = game.findPlayer(viewer);
            JSONObject own = new JSONObject();
            if (p != null) for (String cat : GameEngine.CATEGORIES) own.put(cat, p.answers.containsKey(cat) ? p.answers.get(cat) : "");
            json.put("myAnswers", own);
        }
        if (game.getPhase() == GameEngine.Phase.VOTING || game.getPhase() == GameEngine.Phase.RESULTS) {
            JSONArray all = new JSONArray();
            for (GameEngine.Entry e : game.getEntries()) {
                JSONObject it = new JSONObject();
                it.put("id", e.id);
                it.put("ownerId", e.ownerId);
                GameEngine.Player owner = game.findPlayer(e.ownerId);
                it.put("owner", owner == null ? "Ayrılan oyuncu" : owner.name);
                it.put("category", e.category);
                it.put("answer", e.answer);
                if (game.getPhase() == GameEngine.Phase.VOTING) {
                    it.put("myVote", e.ownerId.equals(viewer) ? "self" : !e.votes.containsKey(viewer) ? "pending" : Boolean.TRUE.equals(e.votes.get(viewer)) ? "yes" : "no");
                    int cast = 0;
                    for (GameEngine.Player p : players) if (!e.ownerId.equals(p.id) && e.votes.containsKey(p.id)) cast++;
                    it.put("cast", cast);
                    it.put("expected", Math.max(0, players.size() - 1));
                } else {
                    it.put("accepted", e.accepted);
                    it.put("points", e.points);
                    it.put("reason", e.reason);
                }
                all.put(it);
            }
            json.put("entries", all);
        }
        return json;
    }

    public synchronized void close() {
        running = false;
        try { if (server != null) server.close(); } catch (Exception ignored) {}
        for (Session s : new ArrayList<>(sessions.values())) s.close();
        sessions.clear();
        pool.shutdownNow();
    }
}

package com.offlineisimsehir.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Entire offline co-op game UI, built with native Android views and no third-party libraries. */
public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(12, 15, 27);
    private static final int CARD = Color.rgb(25, 30, 49);
    private static final int CARD_ALT = Color.rgb(33, 39, 61);
    private static final int OUTLINE = Color.rgb(54, 61, 86);
    private static final int WHITE = Color.rgb(243, 246, 255);
    private static final int MUTED = Color.rgb(163, 173, 197);
    private static final int PURPLE = Color.rgb(140, 116, 255);
    private static final int TEAL = Color.rgb(84, 223, 197);
    private static final int RED = Color.rgb(255, 119, 140);
    private static final int GOLD = Color.rgb(255, 209, 117);

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, String> draft = new HashMap<>();
    private final Map<String, EditText> answerInputs = new HashMap<>();
    private final Map<String, TextView> playerStatusViews = new HashMap<>();
    private LanHost host;
    private LanClient client;
    private JSONObject state;
    private String selfId = "";
    private String screen = "HOME";
    private String renderedKey = "";
    private String previousPhase = "";
    private String draftRound = "";
    private ScrollView scroll;
    private LinearLayout body;
    private TextView countdown;
    private EditText nickInput;
    private EditText ipInput;
    private boolean startingHost;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        showHome();
    }
    private int dp(float v) { return (int) (getResources().getDisplayMetrics().density * v + .5f); }
    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private void layoutBase() {
        FrameLayout background = new FrameLayout(this);
        background.setBackgroundColor(BG);
        background.setFitsSystemWindows(true);
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(34), dp(20), dp(32));
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        background.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        setContentView(background);
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setIncludeFontPadding(true);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    private TextView heading(String label) {
        TextView v = text(label, 25, WHITE, true);
        v.setLineSpacing(dp(2), 1.0f);
        return v;
    }
    private void add(LinearLayout to, View child, int bottomDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(bottomDp);
        to.addView(child, p);
    }
    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        l.setBackground(shape(CARD, 18, OUTLINE));
        return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    private void addWeighted(LinearLayout target, View child, float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, weight);
        p.rightMargin = dp(7);
        target.addView(child, p);
    }
    private Button button(String label, int color, int textColor, Runnable click) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(textColor);
        b.setBackground(shape(color, 13, 0));
        b.setMinHeight(dp(50));
        b.setPadding(dp(12), dp(9), dp(12), dp(9));
        b.setOnClickListener(v -> click.run());
        return b;
    }
    private EditText input(String hint, String value) {
        EditText v = new EditText(this);
        v.setTextSize(16);
        v.setTextColor(WHITE);
        v.setHintTextColor(MUTED);
        v.setHint(hint);
        v.setSingleLine(true);
        v.setSelectAllOnFocus(false);
        v.setPadding(dp(13), dp(12), dp(13), dp(12));
        v.setBackground(shape(CARD_ALT, 12, OUTLINE));
        v.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        v.setText(value);
        return v;
    }
    private TextView chip(String value, int color) {
        TextView v = text(value, 13, color, true);
        v.setPadding(dp(10), dp(7), dp(10), dp(7));
        v.setBackground(shape(CARD_ALT, 10, 0));
        return v;
    }
    private void topline(String eyebrow, String title, String subtitle) {
        TextView badge = text("●  " + eyebrow, 13, TEAL, true);
        add(body, badge, 12);
        add(body, heading(title), 7);
        add(body, text(subtitle, 14, MUTED, false), 22);
    }
    private void footer() {
        TextView f = text("İnternetsiz • Sunucusuz • Yerel ağ üzerinden", 12, MUTED, false);
        f.setGravity(Gravity.CENTER);
        add(body, f, 6);
    }

    private void showHome() {
        closeConnections();
        screen = "HOME";
        renderedKey = "";
        previousPhase = "";
        state = null;
        selfId = "";
        draft.clear();
        layoutBase();
        topline("ÇEVRİMDIŞI PARTİ OYUNU", "İSİM ŞEHİR", "Arkadaşlarınla aynı ağda buluş, harfleri doldur, cevapları birlikte oylayın.");
        LinearLayout hero = card();
        add(hero, text("A  B  C  Ç  D", 33, PURPLE, true), 11);
        add(hero, text("Düşün. Yaz. Oyla. Kazan!", 19, WHITE, true), 9);
        add(hero, text("2–8 kişi • 3/5/10 tur • 60/90/120 sn", 13, MUTED, false), 2);
        add(body, hero, 20);

        add(body, text("OYUNCU ADIN", 12, MUTED, true), 8);
        String savedName = getPreferences(MODE_PRIVATE).getString("nick", "");
        nickInput = input("Örn. Ali", savedName);
        add(body, nickInput, 17);

        add(body, button("+  Oda Kur", PURPLE, WHITE, () -> joinOrHost(true)), 11);
        add(body, text("VEYA BİR ODAYA KATIL", 12, MUTED, true), 9);
        ipInput = input("Oda sahibinin IP adresi • 192.168.x.x", "");
        ipInput.setInputType(InputType.TYPE_CLASS_TEXT);
        add(body, ipInput, 11);
        add(body, button("→  Odaya Katıl", CARD_ALT, WHITE, () -> joinOrHost(false)), 24);
        LinearLayout how = card();
        add(how, text("Nasıl bağlanılır?", 17, WHITE, true), 10);
        add(how, text("1. Tüm telefonlar aynı Wi-Fi ağına veya hotspot'a bağlansın.", 14, MUTED, false), 9);
        add(how, text("2. Bir kişi Oda Kur'a bassın; ekrandaki IP'yi paylaşsın.", 14, MUTED, false), 9);
        add(how, text("3. Diğerleri IP'yi yazarak katılsın. İnternet paketi gerekmez.", 14, MUTED, false), 0);
        add(body, how, 18);
        footer();
    }

    private void joinOrHost(boolean makeHost) {
        if (client != null || host != null) return;
        String name = nickInput.getText().toString().trim();
        if (name.isEmpty()) { nickInput.setError("Bir isim gir."); return; }
        getPreferences(MODE_PRIVATE).edit().putString("nick", name).apply();
        String ip = makeHost ? "127.0.0.1" : ipInput.getText().toString().trim();
        if (!makeHost && !ip.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) {
            ipInput.setError("Örnek: 192.168.1.5"); return;
        }
        startingHost = makeHost;
        if (makeHost) {
            try {
                host = new LanHost();
                host.start();
            } catch (Exception e) {
                if (host != null) host.close();
                host = null;
                toast("Oda açılamadı: " + e.getMessage());
                return;
            }
        }
        layoutBase();
        topline("BAĞLANTI", "Odaya bağlanılıyor…", "Telefonlar aynı yerel ağda olmalı.");
        String hostToken = makeHost ? host.hostSecret() : null;
        screen = "CONNECTING";
        client = new LanClient(ip, name, hostToken, new LanClient.Listener() {
            @Override public void onWelcome(String id) { main.post(() -> selfId = id); }
            @Override public void onState(JSONObject s) { main.post(() -> receiveState(s)); }
            @Override public void onError(String msg) { main.post(() -> toast(msg)); }
            @Override public void onDisconnected() { main.post(() -> {
                if (!"HOME".equals(screen)) {
                    toast("Odayla bağlantı kesildi.");
                    showHome();
                }
            }); }
        });
        client.connect();
    }

    private void closeConnections() {
        if (client != null) { client.close(); client = null; }
        if (host != null) { host.close(); host = null; }
    }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
    private void command(JSONObject msg) { if (client != null) client.send(msg); }
    private JSONObject action(String type) { JSONObject j = new JSONObject(); try { j.put("type", type); } catch (Exception ignored) {} return j; }
    private boolean amHost() {
        if (state == null) return false;
        JSONArray players = state.optJSONArray("players");
        if (players == null) return false;
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = players.optJSONObject(i);
            if (p != null && selfId.equals(p.optString("id"))) return p.optBoolean("host");
        }
        return false;
    }
    private boolean submitted() {
        JSONArray players = state.optJSONArray("players");
        if (players == null) return false;
        for (int i = 0; i < players.length(); i++) {
            JSONObject p = players.optJSONObject(i);
            if (p != null && selfId.equals(p.optString("id"))) return p.optBoolean("submitted");
        }
        return false;
    }
    private void receiveState(JSONObject s) {
        if ("HOME".equals(screen)) return;
        state = s;
        String phase = s.optString("phase");
        String roundKey = s.optInt("round") + ":" + phase;
        if ("WRITING".equals(phase) && !roundKey.equals(draftRound)) {
            draft.clear();
            draftRound = roundKey;
        }
        StringBuilder fingerprint = new StringBuilder(phase).append('/').append(s.optInt("round"))
                .append('/').append(s.optInt("seconds")).append('/').append(s.optInt("rounds"));
        JSONArray participants = s.optJSONArray("players");
        if ("WRITING".equals(phase)) {
            // Do not destroy the answer fields every time another player submits.
            if (participants != null) {
                for (int i = 0; i < participants.length(); i++) {
                    JSONObject p = participants.optJSONObject(i);
                    if (p != null) fingerprint.append(p.optString("id")).append(p.optString("name"));
                }
            }
            fingerprint.append("ownSubmitted:").append(submitted());
        } else fingerprint.append(participants);
        fingerprint.append(s.optJSONArray("entries"));
        if (!fingerprint.toString().equals(renderedKey) || !"GAME".equals(screen)) {
            int savedScroll = scroll == null || !phase.equals(previousPhase) ? 0 : scroll.getScrollY();
            renderedKey = fingerprint.toString();
            previousPhase = phase;
            screen = "GAME";
            renderGame();
            scroll.post(() -> scroll.scrollTo(0, savedScroll));
        }
        updateTimer();
        updatePlayerStatuses();
    }

    private void updatePlayerStatuses() {
        if (state == null || !"WRITING".equals(state.optString("phase"))) return;
        JSONArray participants = state.optJSONArray("players");
        if (participants == null) return;
        for (int i = 0; i < participants.length(); i++) {
            JSONObject p = participants.optJSONObject(i);
            if (p == null) continue;
            TextView status = playerStatusViews.get(p.optString("id"));
            if (status != null) {
                boolean ready = p.optBoolean("submitted");
                status.setText(ready ? "✓ Hazır" : "Yazıyor…");
                status.setTextColor(ready ? TEAL : MUTED);
            }
        }
    }

    private void renderGame() {
        layoutBase();
        if (state == null) return;
        String phase = state.optString("phase");
        int round = state.optInt("round");
        int rounds = state.optInt("rounds");
        LinearLayout top = row();
        TextView brand = text("✦ İSİM ŞEHİR", 18, WHITE, true);
        addWeighted(top, brand, 1f);
        Button leave = button("Çıkış", CARD_ALT, MUTED, this::confirmExit);
        top.addView(leave, new LinearLayout.LayoutParams(dp(92), -2));
        add(body, top, 20);
        String title;
        switch (phase) {
            case "LOBBY": title = "Oyun odası"; break;
            case "WRITING": title = "Cevap zamanı!"; break;
            case "VOTING": title = "Birlikte oylayın"; break;
            default: title = state.optBoolean("final") ? "Oyun bitti!" : "Tur sonuçları";
        }
        add(body, heading(title), 8);
        String subtitle = "LOBBY".equals(phase) ? "Herkes hazır olduğunda oda sahibi başlatır."
                : "Tur " + round + "/" + rounds + "  ·  Harf " + state.optString("letter");
        add(body, text(subtitle, 14, MUTED, false), 18);
        if (!"LOBBY".equals(phase) && !"RESULTS".equals(phase)) {
            LinearLayout clockCard = card();
            LinearLayout line = row();
            TextView letter = text(state.optString("letter"), 56, PURPLE, true);
            addWeighted(line, letter, 1f);
            countdown = text("", 27, GOLD, true);
            countdown.setGravity(Gravity.END);
            line.addView(countdown);
            add(clockCard, line, 6);
            add(clockCard, text("WRITING".equals(phase) ? "Bu harfle başlayan cevapları yaz." : "Oylama süresi dolmadan tüm cevaplara oy ver.", 13, MUTED, false), 0);
            add(body, clockCard, 16);
        } else { countdown = null; }
        renderPlayers(phase);
        switch (phase) {
            case "LOBBY": renderLobby(); break;
            case "WRITING": renderWriting(); break;
            case "VOTING": renderVoting(); break;
            case "RESULTS": renderResults(); break;
        }
        footer();
    }

    private void renderPlayers(String phase) {
        playerStatusViews.clear();
        JSONArray participants = state.optJSONArray("players");
        LinearLayout panel = card();
        add(panel, text("OYUNCULAR  ·  " + (participants == null ? 0 : participants.length()) + "/8", 13, MUTED, true), 12);
        if (participants != null) {
            List<JSONObject> sorted = new ArrayList<>();
            for (int i = 0; i < participants.length(); i++) if (participants.optJSONObject(i) != null) sorted.add(participants.optJSONObject(i));
            if ("RESULTS".equals(phase)) Collections.sort(sorted, (a, b) -> Integer.compare(b.optInt("score"), a.optInt("score")));
            int index = 1;
            for (JSONObject p : sorted) {
                LinearLayout line = row();
                String mark = "RESULTS".equals(phase) ? (index++) + ".  " : p.optBoolean("host") ? "★  " : "●  ";
                String name = p.optString("name") + (selfId.equals(p.optString("id")) ? " (sen)" : "");
                addWeighted(line, text(mark + name, 15, WHITE, true), 1f);
                String status = "WRITING".equals(phase) ? (p.optBoolean("submitted") ? "✓ Hazır" : "Yazıyor…") : p.optInt("score") + " puan";
                TextView statusView = text(status, 13, p.optBoolean("submitted") && "WRITING".equals(phase) ? TEAL : MUTED, true);
                line.addView(statusView);
                if ("WRITING".equals(phase)) playerStatusViews.put(p.optString("id"), statusView);
                add(panel, line, 9);
            }
        }
        add(body, panel, 17);
    }

    private void renderLobby() {
        LinearLayout setup = card();
        add(setup, text("ODA BAĞLANTISI", 12, TEAL, true), 9);
        List<String> ips = NetworkUtils.localIps();
        String joined = ips.isEmpty() ? "Yerel IP bulunamadı. Wi-Fi veya hotspot'u aç." : android.text.TextUtils.join("   ·   ", ips);
        add(setup, text(joined, 18, WHITE, true), 10);
        if (amHost()) {
            add(setup, button("IP adresini kopyala", CARD_ALT, WHITE, () -> {
                if (ips.isEmpty()) { toast("Yerel IP adresi bulunamadı."); return; }
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("Oda IP", ips.get(0)));
                toast("IP kopyalandı: " + ips.get(0));
            }), 8);
        }
        add(setup, text(amHost() ? "Diğerleri bu adresi Odaya Katıl ekranına yazmalı." : "Odaya bağlısın. Oda sahibinin oyunu başlatmasını bekle.", 13, MUTED, false), 0);
        add(body, setup, 17);
        LinearLayout rules = card();
        add(rules, text("OYUN KURALLARI", 13, MUTED, true), 9);
        add(rules, text("✓ Oy birliği + benzersiz cevap: 10 puan\n✓ Oy birliği + tekrarlanan cevap: 5 puan\n✕ Reddedilen veya yanlış harf: 0 puan\n• Kendi cevabına oy veremezsin.", 14, WHITE, false), 0);
        add(body, rules, 16);
        if (!amHost()) {
            add(body, text("Oda sahibi ayarları seçip oyunu başlatacak.", 14, MUTED, false), 10);
            return;
        }
        LinearLayout config = card();
        add(config, text("TUR SÜRESİ", 13, MUTED, true), 9);
        add(config, choices(new int[]{60, 90, 120}, state.optInt("seconds"), "seconds", " sn"), 14);
        add(config, text("TUR SAYISI", 13, MUTED, true), 9);
        add(config, choices(new int[]{3, 5, 10}, state.optInt("rounds"), "rounds", " tur"), 0);
        add(body, config, 14);
        add(body, button("▶  Oyunu Başlat", PURPLE, WHITE, () -> command(action("start"))), 15);
    }

    private LinearLayout choices(int[] options, int current, String field, String suffix) {
        LinearLayout l = row();
        for (int option : options) {
            Button b = button(option + suffix, option == current ? PURPLE : CARD_ALT, WHITE, () -> {
                JSONObject obj = action("settings");
                try {
                    obj.put("seconds", field.equals("seconds") ? option : state.optInt("seconds"));
                    obj.put("rounds", field.equals("rounds") ? option : state.optInt("rounds"));
                } catch (Exception ignored) {}
                command(obj);
            });
            addWeighted(l, b, 1f);
        }
        return l;
    }

    private void renderWriting() {
        if (submitted()) {
            LinearLayout done = card();
            add(done, text("✓  Cevapların gönderildi!", 22, TEAL, true), 12);
            add(done, text("Diğer oyuncuların cevaplarını bekliyorsun. Herkes gönderince oylama otomatik başlayacak.", 15, MUTED, false), 0);
            add(body, done, 24);
            return;
        }
        answerInputs.clear();
        LinearLayout panel = card();
        add(panel, text("6 KATEGORİ", 13, MUTED, true), 15);
        for (String category : GameEngine.CATEGORIES) {
            add(panel, text(category.toUpperCase(java.util.Locale.forLanguageTag("tr-TR")), 12, TEAL, true), 5);
            EditText field = input(state.optString("letter") + " ile başlayan " + category.toLowerCase(java.util.Locale.forLanguageTag("tr-TR")), draft.containsKey(category) ? draft.get(category) : "");
            field.setMaxLines(1);
            field.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(40)});
            answerInputs.put(category, field);
            field.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) { draft.put(category, s.toString()); }
                @Override public void afterTextChanged(Editable e) {}
            });
            add(panel, field, 13);
        }
        add(body, panel, 15);
        add(body, button("✓  Cevapları Gönder", TEAL, BG, () -> {
            JSONObject answers = new JSONObject();
            try {
                for (String cat : GameEngine.CATEGORIES) {
                    EditText field = answerInputs.get(cat);
                    answers.put(cat, field == null ? "" : field.getText().toString().trim());
                }
                JSONObject msg = action("submit");
                msg.put("answers", answers);
                command(msg);
                View focused = getCurrentFocus();
                if (focused != null) {
                    InputMethodManager keyboard = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    keyboard.hideSoftInputFromWindow(focused.getWindowToken(), 0);
                    focused.clearFocus();
                }
            } catch (Exception ignored) {}
        }), 15);
        add(body, text("Boş kategori bırakabilirsin. Gönderdikten sonra cevaplarını değiştiremezsin.", 13, MUTED, false), 14);
    }

    private void renderVoting() {
        JSONArray items = state.optJSONArray("entries");
        if (items == null || items.length() == 0) {
            add(body, text("Bu tur cevap girilmemiş.", 16, MUTED, false), 20);
            return;
        }
        int outstanding = 0;
        for (int i = 0; i < items.length(); i++) {
            JSONObject it = items.optJSONObject(i);
            if (it != null && "pending".equals(it.optString("myVote"))) outstanding++;
        }
        add(body, text(outstanding == 0 ? "✓ Tüm oylarını verdin. Diğerleri bekleniyor." : "Oylanacak " + outstanding + " cevap kaldı.", 15, outstanding == 0 ? TEAL : GOLD, true), 17);
        for (int i = 0; i < items.length(); i++) {
            JSONObject it = items.optJSONObject(i);
            if (it == null) continue;
            LinearLayout box = card();
            add(box, text(it.optString("owner") + "  /  " + it.optString("category"), 13, MUTED, true), 8);
            add(box, text(it.optString("answer"), 22, WHITE, true), 9);
            String vote = it.optString("myVote");
            if ("self".equals(vote)) {
                add(box, text("Kendi cevabın • Diğerlerinin oyları bekleniyor.", 13, MUTED, false), 0);
            } else {
                LinearLayout actions = row();
                String id = it.optString("id");
                addWeighted(actions, button("✓  Kabul", "yes".equals(vote) ? TEAL : CARD_ALT, "yes".equals(vote) ? BG : WHITE, () -> sendVote(id, true)), 1f);
                addWeighted(actions, button("✕  Ret", "no".equals(vote) ? RED : CARD_ALT, "no".equals(vote) ? BG : WHITE, () -> sendVote(id, false)), 1f);
                add(box, actions, 9);
                add(box, text(it.optInt("cast") + "/" + it.optInt("expected") + " oy kullanıldı · Oyunu değiştirebilirsin.", 12, MUTED, false), 0);
            }
            add(body, box, 11);
        }
    }
    private void sendVote(String id, boolean yes) {
        JSONObject j = action("vote");
        try { j.put("entryId", id); j.put("yes", yes); } catch (Exception ignored) {}
        command(j);
    }

    private void renderResults() {
        JSONArray list = state.optJSONArray("players");
        if (state.optBoolean("final") && list != null && list.length() > 0) {
            List<JSONObject> arr = new ArrayList<>();
            for (int i = 0; i < list.length(); i++) if (list.optJSONObject(i) != null) arr.add(list.optJSONObject(i));
            arr.sort((a, b) -> Integer.compare(b.optInt("score"), a.optInt("score")));
            int highest = arr.get(0).optInt("score");
            StringBuilder winners = new StringBuilder();
            for (JSONObject p : arr) {
                if (p.optInt("score") != highest) break;
                if (winners.length() > 0) winners.append(" & ");
                winners.append(p.optString("name"));
            }
            LinearLayout winner = card();
            add(winner, text("🏆  KAZANAN", 13, GOLD, true), 9);
            add(winner, text(winners.toString(), 27, WHITE, true), 8);
            add(winner, text(highest + " puan", 18, TEAL, true), 0);
            add(body, winner, 17);
        }
        JSONArray items = state.optJSONArray("entries");
        add(body, text("CEVAP DEĞERLENDİRMELERİ", 13, MUTED, true), 12);
        if (items == null || items.length() == 0) {
            add(body, text("Bu tur hiçbir cevap gönderilmedi.", 15, MUTED, false), 16);
        } else {
            for (int i = 0; i < items.length(); i++) {
                JSONObject it = items.optJSONObject(i);
                if (it == null) continue;
                LinearLayout box = card();
                add(box, text(it.optString("owner") + "  /  " + it.optString("category"), 12, MUTED, true), 6);
                LinearLayout line = row();
                addWeighted(line, text(it.optString("answer"), 19, WHITE, true), 1f);
                boolean accepted = it.optBoolean("accepted");
                line.addView(chip((accepted ? "+" : "") + it.optInt("points") + "  " + (accepted ? "✓" : "✕"), accepted ? TEAL : RED));
                add(box, line, 6);
                add(box, text(it.optString("reason"), 12, MUTED, false), 0);
                add(body, box, 10);
            }
        }
        if (amHost()) {
            String label = state.optBoolean("final") ? "↻  Yeniden Oyna" : "→  Sonraki Tur";
            add(body, button(label, PURPLE, WHITE, () -> command(action(state.optBoolean("final") ? "restart" : "next"))), 20);
        } else {
            add(body, text(state.optBoolean("final") ? "Oda sahibi isterse yeni oyun başlatabilir." : "Sonraki tur için oda sahibini bekle.", 14, MUTED, false), 17);
        }
    }

    private void updateTimer() {
        if (countdown == null || state == null) return;
        long ms = Math.max(0, state.optLong("remainingMs"));
        int seconds = (int) ((ms + 999) / 1000);
        countdown.setText(String.format(java.util.Locale.ROOT, "%02d:%02d", seconds / 60, seconds % 60));
        countdown.setTextColor(seconds < 11 ? RED : GOLD);
    }

    private void confirmExit() {
        new AlertDialog.Builder(this)
                .setTitle("Odadan ayrılsın mı?")
                .setMessage(amHost() ? "Odayı kapatırsan diğer oyuncuların bağlantısı da kesilir." : "Oyun odasından çıkacaksın.")
                .setNegativeButton("Vazgeç", null)
                .setPositiveButton("Çık", (d, w) -> showHome())
                .show();
    }
    @Override public void onBackPressed() {
        if (!"HOME".equals(screen)) confirmExit();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        closeConnections();
        super.onDestroy();
    }
}

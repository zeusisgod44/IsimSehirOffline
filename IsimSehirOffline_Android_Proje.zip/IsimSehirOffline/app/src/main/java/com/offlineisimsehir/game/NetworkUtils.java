package com.offlineisimsehir.game;

import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

public final class NetworkUtils {
    private NetworkUtils() {}
    /** Returns private interface addresses, prioritized for Wi-Fi / local hotspot. */
    public static List<String> localIps() {
        List<String> preferred = new ArrayList<>();
        List<String> other = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            for (NetworkInterface nic : Collections.list(interfaces)) {
                if (!nic.isUp() || nic.isLoopback()) continue;
                for (java.net.InetAddress address : Collections.list(nic.getInetAddresses())) {
                    if (!(address instanceof Inet4Address) || address.isLoopbackAddress() || !address.isSiteLocalAddress()) continue;
                    String ip = address.getHostAddress();
                    if (nic.getName().startsWith("wlan") || nic.getName().startsWith("ap") || nic.getName().startsWith("swlan")) preferred.add(ip);
                    else other.add(ip);
                }
            }
        } catch (Exception ignored) {}
        preferred.addAll(other);
        return preferred;
    }
}

package org.gradle.wrapper;

import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Small, self-contained Gradle launcher for environments without a system Gradle.
 * The wrapper's version is read from gradle-wrapper.properties.
 * This is not the official Gradle wrapper implementation; its source is included.
 */
public final class GradleWrapperMain {
    public static void main(String[] args) throws Exception {
        Path project = new File(System.getProperty("user.dir")).toPath();
        Path propsPath = project.resolve("gradle/wrapper/gradle-wrapper.properties");
        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(propsPath)) { properties.load(input); }
        String uri = properties.getProperty("distributionUrl");
        if (uri == null || !uri.startsWith("https://services.gradle.org/distributions/gradle-")) {
            throw new IllegalStateException("Gradle dağıtım adresi tanınmıyor: " + uri);
        }
        String zipName = uri.substring(uri.lastIndexOf('/') + 1);
        String version = zipName.replace("-bin.zip", "").replace("-all.zip", "");
        Path home = new File(System.getProperty("user.home"), ".gradle/wrapper/dists/isimsehir-" + version).toPath();
        Path binary = home.resolve(version).resolve("bin/gradle" + (System.getProperty("os.name").toLowerCase().contains("win") ? ".bat" : ""));
        if (!Files.isRegularFile(binary)) {
            Files.createDirectories(home);
            Path zip = home.resolve(zipName);
            System.out.println("Gradle ilk kez indiriliyor: " + uri);
            try (InputStream in = new URL(uri).openStream()) {
                Files.copy(in, zip, StandardCopyOption.REPLACE_EXISTING);
            }
            try (ZipInputStream zin = new ZipInputStream(Files.newInputStream(zip))) {
                ZipEntry entry;
                while ((entry = zin.getNextEntry()) != null) {
                    Path target = home.resolve(entry.getName()).normalize();
                    if (!target.startsWith(home)) throw new IllegalStateException("Unsafe ZIP entry");
                    if (entry.isDirectory()) Files.createDirectories(target);
                    else {
                        Files.createDirectories(target.getParent());
                        Files.copy(zin, target, StandardCopyOption.REPLACE_EXISTING);
                    }
                }
            }
            Files.deleteIfExists(zip);
            if (!Files.isRegularFile(binary)) throw new IllegalStateException("Gradle binary bulunamadı: " + binary);
            binary.toFile().setExecutable(true);
        }
        List<String> cmd = new ArrayList<>();
        cmd.add(binary.toAbsolutePath().toString());
        for (String arg : args) cmd.add(arg);
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.directory(project.toFile());
        pb.inheritIO();
        int code = pb.start().waitFor();
        if (code != 0) System.exit(code);
    }
}

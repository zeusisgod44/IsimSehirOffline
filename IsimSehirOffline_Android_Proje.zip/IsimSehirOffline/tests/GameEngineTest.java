import com.offlineisimsehir.game.GameEngine;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class GameEngineTest {
    private static void check(boolean result, String message) {
        if (!result) throw new AssertionError(message);
    }
    private static Map<String, String> answers(String category, String answer) {
        Map<String, String> map = new HashMap<>();
        map.put(category, answer);
        return map;
    }
    private static GameEngine.Entry entry(GameEngine e, String ownerId, String category) {
        for (GameEngine.Entry it : e.getEntries()) {
            if (it.ownerId.equals(ownerId) && it.category.equals(category)) return it;
        }
        throw new AssertionError("Missing entry " + ownerId + " " + category);
    }
    private static void voteAllYes(GameEngine game) {
        List<GameEngine.Entry> entries = game.getEntries();
        List<GameEngine.Player> players = game.getPlayers();
        for (GameEngine.Entry e : entries) {
            for (GameEngine.Player p : players) {
                if (!p.id.equals(e.ownerId) && game.getPhase() == GameEngine.Phase.VOTING) game.vote(p.id, e.id, true);
            }
        }
    }

    private static void testConsensusDuplicatesAndRestart() {
        GameEngine g = new GameEngine();
        GameEngine.Player ali = g.addPlayer("Ali", true);
        GameEngine.Player ayse = g.addPlayer("Ayşe", false);
        GameEngine.Player can = g.addPlayer("Can", false);
        g.settings(ali.id, 60, 3);
        g.start(ali.id);
        String ch = g.getLetter();
        g.submit(ali.id, answers("Şehir", ch + "nkara"));
        g.submit(ayse.id, answers("Şehir", ch + "NKARA"));
        g.submit(can.id, answers("Şehir", ch + "ntalya"));
        check(g.getPhase() == GameEngine.Phase.VOTING, "All submit -> vote");
        voteAllYes(g);
        check(g.getPhase() == GameEngine.Phase.RESULTS, "Vote completion -> results");
        check(entry(g, ali.id, "Şehir").points == 5, "Duplicate score 5");
        check(entry(g, ayse.id, "Şehir").points == 5, "Case-insensitive duplicate score 5");
        check(entry(g, can.id, "Şehir").points == 10, "Unique score 10");
        check(ali.score == 5 && ayse.score == 5 && can.score == 10, "Scores added");
        g.nextRound(ali.id);
        check(g.getRound() == 2 && g.getPhase() == GameEngine.Phase.WRITING, "Next round");
        String nextLetter = g.getLetter();
        check(!ch.equals(nextLetter), "Letters do not repeat in the same game");
        g.submit(ali.id, answers("İsim", nextLetter + "li"));
        g.submit(ayse.id, answers("İsim", nextLetter + "yse"));
        g.submit(can.id, answers("İsim", nextLetter + "an"));
        voteAllYes(g);
        g.nextRound(ali.id);
        g.submit(ali.id, new HashMap<>());
        g.submit(ayse.id, new HashMap<>());
        g.submit(can.id, new HashMap<>());
        check(g.isFinalResults(), "Final results after last round");
        g.restart(ali.id);
        check(g.getRound() == 0 && ali.score == 0 && g.getPhase() == GameEngine.Phase.LOBBY, "Restart clears scores");
    }

    private static void testRejectionAndLetterRule() {
        GameEngine g = new GameEngine();
        GameEngine.Player p1 = g.addPlayer("A", true);
        GameEngine.Player p2 = g.addPlayer("B", false);
        g.start(p1.id);
        String ch = g.getLetter();
        String wrong = ch.equals("A") ? "Zarmut" : "Armut";
        g.submit(p1.id, answers("İsim", wrong));
        g.submit(p2.id, answers("İsim", ch + "li"));
        GameEngine.Entry e1 = entry(g, p1.id, "İsim");
        GameEngine.Entry e2 = entry(g, p2.id, "İsim");
        g.vote(p2.id, e1.id, true); // Even all-yes cannot bypass wrong-letter rule.
        g.vote(p1.id, e2.id, false);
        check(e1.points == 0 && !e1.accepted, "Wrong letter gives 0 despite acceptance vote");
        check(e2.points == 0 && !e2.accepted, "Reject gives 0");
    }

    private static void testAuthenticationAndConstraints() {
        GameEngine g = new GameEngine();
        GameEngine.Player p1 = g.addPlayer("Host", true);
        GameEngine.Player p2 = g.addPlayer("Host", false);
        check(!p1.name.equals(p2.name), "Duplicate names are disambiguated");
        boolean blocked = false;
        try { g.start(p2.id); } catch (SecurityException expected) { blocked = true; }
        check(blocked, "Guests cannot start a room");
        g.start(p1.id);
        blocked = false;
        try { g.addPlayer("Late", false); } catch (IllegalStateException expected) { blocked = true; }
        check(blocked, "Late join is blocked");
        g.submit(p1.id, answers("İsim", g.getLetter() + "li"));
        g.submit(p2.id, answers("İsim", g.getLetter() + "yşe"));
        blocked = false;
        try { g.vote(p1.id, entry(g, p1.id, "İsim").id, true); } catch (IllegalArgumentException expected) { blocked = true; }
        check(blocked, "Own votes are blocked");
    }

    private static void testTimeoutsAndVoteChange() throws Exception {
        GameEngine g = new GameEngine();
        GameEngine.Player p1 = g.addPlayer("Host", true);
        GameEngine.Player p2 = g.addPlayer("Guest", false);
        g.start(p1.id);
        String letter = g.getLetter();
        g.submit(p1.id, answers("İsim", letter + "li"));
        java.lang.reflect.Field deadline = GameEngine.class.getDeclaredField("deadlineMs");
        deadline.setAccessible(true);
        deadline.setLong(g, System.currentTimeMillis() - 100);
        check(g.tick(), "Writing timeout transitions");
        check(g.getPhase() == GameEngine.Phase.VOTING, "Writing timeout enters vote");
        GameEngine.Entry answer = entry(g, p1.id, "İsim");
        g.vote(p2.id, answer.id, false);
        // In a two-person room, submitting the only vote completes the vote immediately.
        check(g.getPhase() == GameEngine.Phase.RESULTS && answer.points == 0, "Rejection stays 0");

        GameEngine g2 = new GameEngine();
        GameEngine.Player a = g2.addPlayer("A", true);
        GameEngine.Player b = g2.addPlayer("B", false);
        GameEngine.Player c = g2.addPlayer("C", false);
        g2.start(a.id);
        g2.submit(a.id, answers("İsim", g2.getLetter() + "da"));
        g2.submit(b.id, new HashMap<>());
        g2.submit(c.id, new HashMap<>());
        GameEngine.Entry e = entry(g2, a.id, "İsim");
        g2.vote(b.id, e.id, false);
        g2.vote(b.id, e.id, true); // The same voter can change their mind while voting is open.
        deadline.setLong(g2, System.currentTimeMillis() - 100);
        g2.tick();
        check(!e.accepted, "Missing vote means no unanimous approval at timeout");
    }

    public static void main(String[] args) throws Exception {
        testConsensusDuplicatesAndRestart();
        testRejectionAndLetterRule();
        testAuthenticationAndConstraints();
        testTimeoutsAndVoteChange();
        System.out.println("OK: scoring, unanimous voting, timeouts, rounds, reset, access rules, unique letters.");
    }
}
